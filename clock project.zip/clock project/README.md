# htmlProjectTemplate
A basic HTML project folder with linked CSS, JS, and jQuery files.
